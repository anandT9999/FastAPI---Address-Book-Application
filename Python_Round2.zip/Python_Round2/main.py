from fastapi import FastAPI, HTTPException, Query, Depends
from typing import List
from models import Address, CreateAddress, UpdateAddress
from database import Database

import logging

logging.basicConfig(level=logging.INFO)

app = FastAPI()

def get_database():
    return Database()

@app.post("/addresses/", response_model=Address)
def create_address(address: CreateAddress, db: Database = Depends(get_database)):
    try:
        logging.info("Creating new address")
        return db.create_address(address)
    except Exception as e:
        logging.error(f"Error creating address: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/addresses/{address_id}", response_model=Address)
def update_address(address_id: int, address: UpdateAddress, db: Database = Depends(get_database)):
    try:
        logging.info(f"Updating address with ID: {address_id}")
        updated_address = db.update_address(address_id, address)
        if updated_address is None:
            raise HTTPException(status_code=404, detail="Address not found")
        return updated_address
    except Exception as e:
        logging.error(f"Error updating address: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/addresses/{address_id}")
def delete_address(address_id: int, db: Database = Depends(get_database)):
    try:
        logging.info(f"Deleting address with ID: {address_id}")
        return db.delete_address(address_id)
    except Exception as e:
        logging.error(f"Error deleting address: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/addresses/", response_model=List[Address])
def get_addresses(db: Database = Depends(get_database)):
    try:
        logging.info("Retrieving all addresses")
        return db.get_addresses()
    except Exception as e:
        logging.error(f"Error retrieving addresses: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/addresses/{address_id}", response_model=Address)
def get_address(address_id: int, db: Database = Depends(get_database)):
    try:
        logging.info(f"Retrieving address with ID: {address_id}")
        return db.get_address(address_id)
    except Exception as e:
        logging.error(f"Error retrieving address: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/addresses/nearby/", response_model=List[Address])
def get_nearby_addresses(latitude: float = Query(..., description="Latitude of the location"),
                         longitude: float = Query(..., description="Longitude of the location"),
                         distance: float = Query(..., description="Distance in kilometers"),
                         db: Database = Depends(get_database)):
    try:
        logging.info("Retrieving nearby addresses")
        return db.get_nearby_addresses(latitude, longitude, distance)
    except Exception as e:
        logging.error(f"Error retrieving nearby addresses: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")
