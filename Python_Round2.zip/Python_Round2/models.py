from pydantic import BaseModel , validator
from typing import Optional

class Address(BaseModel):
    id: int
    street: str
    city: str
    state: str
    country: str
    coordinates: str


class CreateAddress(BaseModel):
    street: str
    city: str
    state: str
    country: str
    coordinates: str
    @validator('coordinates')
    def validate_coordinates(cls, v):
        try:
            latitude_str, longitude_str = v.split(',')
            latitude = float(latitude_str.strip())
            longitude = float(longitude_str.strip())
            if -90 <= latitude <= 90 and -180 <= longitude <= 180:
                return v
            else:
                raise ValueError('Latitude must be between -90 and 90, and longitude must be between -180 and 180')
        except ValueError:
            raise ValueError('Coordinates must be in the format "latitude, longitude"')

class UpdateAddress(BaseModel):
    street: str
    city: str
    state: str
    country: str
    coordinates: str
