import sqlite3
from models import Address
from geopy.distance import geodesic

class Database:
    def __init__(self, db_name="address_book.db"):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS addresses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                street TEXT NOT NULL,
                city TEXT NOT NULL,
                state TEXT NOT NULL,
                country TEXT NOT NULL,
                coordinates TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def create_address(self, address):
        query = '''
            INSERT INTO addresses (street, city, state, country, coordinates)
            VALUES (?, ?, ?, ?, ?)
        '''
        self.cursor.execute(query, (address.street, address.city, address.state, address.country, address.coordinates))
        self.conn.commit()
        address_id = self.cursor.lastrowid
        return Address(id=address_id, **address.dict())

    def update_address(self, address_id, address):
        query = '''
            UPDATE addresses
            SET street=?, city=?, state=?, country=?, coordinates=?
            WHERE id=?
        '''
        self.cursor.execute(query, (address.street, address.city, address.state, address.country, address.coordinates, address_id))
        self.conn.commit()
        if self.cursor.rowcount == 0:
            return None
        else:
            return Address(id=address_id, **address.dict())

    def delete_address(self, address_id):
        query = '''
            DELETE FROM addresses
            WHERE id=?
        '''
        self.cursor.execute(query, (address_id,))
        self.conn.commit()
        if self.cursor.rowcount == 0:
            return None
        else:
            return {"message": "Address deleted successfully"}

    def get_addresses(self):
        query = '''
            SELECT id, street, city, state, country, coordinates
            FROM addresses
        '''
        self.cursor.execute(query)
        addresses = []
        for row in self.cursor.fetchall():
            addresses.append(Address(id=row[0], street=row[1], city=row[2], state=row[3], country=row[4], coordinates=row[5]))
        return addresses

    def get_address(self, address_id):
        query = '''
            SELECT id, street, city, state, country, coordinates
            FROM addresses
            WHERE id=?
        '''
        self.cursor.execute(query, (address_id,))
        row = self.cursor.fetchone()
        if row is not None:
            return Address(id=row[0], street=row[1], city=row[2], state=row[3], country=row[4], coordinates=row[5])
        else:
            return None

    def get_nearby_addresses(self, latitude, longitude, distance):
        user_coordinates = (latitude, longitude)
        addresses = []

        query = '''
            SELECT id, street, city, state, country, coordinates
            FROM addresses
        '''
        self.cursor.execute(query)

        for row in self.cursor.fetchall():
            address_coordinates = row[5].replace('° N', '').replace('° W', '').replace(' ', '')
            latitude, longitude = map(float, address_coordinates.split(','))
            if geodesic(user_coordinates, (latitude, longitude)).kilometers <= distance:
                addresses.append(Address(id=row[0], street=row[1], city=row[2], state=row[3], country=row[4], coordinates=row[5]))

        return addresses
